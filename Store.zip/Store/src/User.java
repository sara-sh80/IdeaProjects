public class User {
    private String UserName;
    private int Password;
    public User(String username, int password){
        this.UserName = username;
        this.Password = password;
    }
}
