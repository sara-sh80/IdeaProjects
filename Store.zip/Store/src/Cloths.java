public class Cloths extends Product {

    public Cloths(String companyName,double volume, ProductCategory category){
        super(companyName ,volume, category);
    }
}
