public class JunkFood extends Food {
    public JunkFood(String companyName,double volume, ProductCategory category, String expirationDate){
        super(companyName, volume, category, expirationDate);
    }
}
