public class Dairy extends Food {
    public Dairy(String companyName,double volume, ProductCategory category, String expirationDate){
        super(companyName, volume, category, expirationDate);

    }
}
